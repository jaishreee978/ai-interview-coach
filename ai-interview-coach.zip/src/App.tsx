import { useState } from "react";
import { Brain } from "lucide-react";
import Dashboard from "./components/Dashboard";
import SetupSession from "./components/SetupSession";
import InterviewStage from "./components/InterviewStage";
import SessionReview from "./components/SessionReview";

type ViewState = "dashboard" | "setup" | "stage" | "review";

export default function App() {
  const [userId] = useState<string>("guest_user");
  const [view, setView] = useState<ViewState>("dashboard");
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);

  // Handle Select Session from Dashboard
  function handleSelectSession(sessionId: string) {
    setActiveSessionId(sessionId);
    setView("review");
  }

  // Handle New Session setup completed
  function handleSessionCreated(sessionId: string) {
    setActiveSessionId(sessionId);
    setView("stage");
  }

  // Handle Interview completed
  function handleInterviewCompleted(sessionId: string) {
    setActiveSessionId(sessionId);
    setView("review");
  }

  // Handle Retake session
  function handleRetakeSession() {
    setView("setup");
  }

  return (
    <div className="min-h-screen bg-[#050608] text-slate-100 flex flex-col font-sans" id="app-wrapper">
      {/* Immersive Top Navigation Bar */}
      <header className="sticky top-0 z-40 h-16 border-b border-white/5 flex items-center justify-between px-6 bg-[#0A0C10]/80 backdrop-blur-md">
        <div className="max-w-7xl w-full mx-auto flex items-center justify-between">
          
          {/* Logo / Brand */}
          <div 
            onClick={() => { if (view !== "stage") setView("dashboard"); }} 
            className="flex items-center gap-3 cursor-pointer select-none"
            id="brand-logo"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.4)]">
              <Brain className="text-white" size={18} />
            </div>
            <div>
              <h1 className="font-extrabold tracking-tight text-white text-base leading-none">
                AI INTERVIEW <span className="text-cyan-400 uppercase text-xs ml-1 tracking-[0.2em] font-medium">Coach</span>
              </h1>
            </div>
          </div>

          {/* User Session Indicators */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1 bg-slate-800/30 rounded-full border border-white/5 text-xs">
              <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
              <span className="text-slate-400 font-mono text-[10px] hidden sm:inline">
                PRACTICE SPACE (OPEN ACCESS)
              </span>
              <span className="text-cyan-400 font-bold sm:hidden">LIVE</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-8 flex flex-col justify-center" id="main-content-area">

        {view === "dashboard" && userId && (
          <Dashboard 
            userId={userId} 
            onStartNew={() => setView("setup")} 
            onSelectSession={handleSelectSession} 
          />
        )}

        {view === "setup" && userId && (
          <SetupSession 
            userId={userId} 
            onSessionCreated={handleSessionCreated} 
            onCancel={() => setView("dashboard")} 
          />
        )}

        {view === "stage" && userId && activeSessionId && (
          <InterviewStage 
            userId={userId} 
            sessionId={activeSessionId} 
            onExit={() => setView("dashboard")} 
            onCompleted={handleInterviewCompleted} 
          />
        )}

        {view === "review" && userId && activeSessionId && (
          <SessionReview 
            userId={userId} 
            sessionId={activeSessionId} 
            onBackToDashboard={() => setView("dashboard")} 
            onRetake={handleRetakeSession} 
          />
        )}
      </main>

      {/* Aesthetic minimalistic footer */}
      <footer className="border-t border-slate-950 bg-[#070a12]/50 py-6 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 AI Interview Coach. Designed for peak cognitive confidence.</p>
          <div className="flex items-center gap-4 text-slate-600">
            <span>Secure SSL Endpoint</span>
            <span>•</span>
            <span>Real-time Audio NLP</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
