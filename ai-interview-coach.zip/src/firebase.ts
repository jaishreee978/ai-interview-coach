import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyC0U4rCmlcYAlER0GlH4tV1KhAFJGX5S94",
  authDomain: "gen-lang-client-0954044884.firebaseapp.com",
  projectId: "gen-lang-client-0954044884",
  storageBucket: "gen-lang-client-0954044884.firebasestorage.app",
  messagingSenderId: "902469601691",
  appId: "1:902469601691:web:931017eb93ec2af79e393e"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, "ai-studio-efd43d32-ddb3-4c47-8c37-afed7d8b8719");
export const auth = getAuth(app);

// Simple auth check to see if we already have a session
export async function ensureAuthenticated(): Promise<string> {
  if (auth.currentUser) {
    return auth.currentUser.uid;
  }
  return new Promise((resolve, reject) => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      unsubscribe();
      if (user) {
        resolve(user.uid);
      } else {
        reject(new Error("No active authenticated session found."));
      }
    });
  });
}

// Handle Google Sign-In
export async function signInWithGoogle(): Promise<string> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({
    prompt: 'select_account'
  });
  const credential = await signInWithPopup(auth, provider);
  return credential.user.uid;
}

// Handle Email/Password Sign-In
export async function loginWithEmail(email: string, pass: string): Promise<string> {
  const credential = await signInWithEmailAndPassword(auth, email, pass);
  return credential.user.uid;
}

// Handle Email/Password Sign-Up
export async function registerWithEmail(email: string, pass: string): Promise<string> {
  const credential = await createUserWithEmailAndPassword(auth, email, pass);
  return credential.user.uid;
}

// Handle Sign Out
export async function logout(): Promise<void> {
  await signOut(auth);
}
