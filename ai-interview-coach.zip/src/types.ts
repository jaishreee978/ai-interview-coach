export interface UserProfile {
  userId: string;
  name: string;
  targetRole: string;
  targetCompany: string;
  experienceLevel: 'Entry-Level' | 'Mid-Level' | 'Senior-Level';
  createdAt: string;
}

export interface InterviewSession {
  id: string;
  userId: string;
  createdAt: string;
  role: string;
  experienceLevel: string;
  company: string;
  status: 'ongoing' | 'completed';
  questionsCount: number;
  score?: number; // 0-100 overall score
  feedback?: string; // Overall feedback
  categoryScores?: {
    technical?: number;
    communication?: number;
    problemSolving?: number;
    situational?: number;
  };
}

export interface InterviewQuestionResponse {
  id: string;
  sessionId: string;
  index: number;
  question: string;
  category: 'Behavioral' | 'Technical' | 'Situational' | 'Resume' | 'General';
  userAnswer?: string;
  isAnswered: boolean;
  answeredAt?: string;
  feedback?: {
    score: number; // 0-100
    pros: string[];
    cons: string[];
    betterResponse: string;
    communicationFeedback: string;
  };
}

export interface ProgressDataPoint {
  date: string;
  score: number;
  sessionTitle: string;
}

export interface SkillScore {
  subject: string;
  A: number;
  fullMark: number;
}
