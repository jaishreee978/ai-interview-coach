import { 
  collection, 
  query, 
  where, 
  getDocs, 
  orderBy, 
  addDoc, 
  getDoc, 
  doc, 
  updateDoc 
} from "firebase/firestore";
import { db } from "./firebase";
import { InterviewSession, InterviewQuestionResponse } from "./types";

// Determine if we should use LocalStorage fallback for a specific userId or if Firestore is unavailable
export function isGuestUser(userId: string): boolean {
  return !userId || userId === "guest_user" || userId.startsWith("guest_") || userId.startsWith("local_");
}

export interface LocalUser {
  uid: string;
  email: string;
  password?: string;
}

export function getLocalUsers(): LocalUser[] {
  try {
    const data = localStorage.getItem("local_users");
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveLocalUsers(users: LocalUser[]) {
  try {
    localStorage.setItem("local_users", JSON.stringify(users));
  } catch {}
}

export function localRegister(email: string, pass: string): string {
  const users = getLocalUsers();
  const lowerEmail = email.toLowerCase().trim();
  if (users.some(u => u.email === lowerEmail)) {
    const err = new Error("This email is already registered.");
    (err as any).code = "auth/email-already-in-use";
    throw err;
  }
  const uid = "local_" + Math.random().toString(36).substring(2, 11);
  users.push({ uid, email: lowerEmail, password: pass });
  saveLocalUsers(users);
  return uid;
}

export function localLogin(email: string, pass: string): string {
  const users = getLocalUsers();
  const lowerEmail = email.toLowerCase().trim();
  const found = users.find(u => u.email === lowerEmail);
  if (!found || found.password !== pass) {
    const err = new Error("Incorrect email or password.");
    (err as any).code = "auth/invalid-credential";
    throw err;
  }
  return found.uid;
}

export function getLocalUserEmail(uid: string): string | null {
  if (uid === "guest_user") return "guest@local.practice";
  if (uid.startsWith("local_")) {
    const users = getLocalUsers();
    const found = users.find(u => u.uid === uid);
    return found ? found.email : "sandbox@local.practice";
  }
  return null;
}

// Helper: Get local sessions from localStorage
function getLocalSessions(): InterviewSession[] {
  try {
    const data = localStorage.getItem("interview_sessions");
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error("Failed to read local sessions:", e);
    return [];
  }
}

// Helper: Set local sessions to localStorage
function saveLocalSessions(sessions: InterviewSession[]) {
  try {
    localStorage.setItem("interview_sessions", JSON.stringify(sessions));
  } catch (e) {
    console.error("Failed to save local sessions:", e);
  }
}

// Helper: Get local questions from localStorage
function getLocalQuestions(): InterviewQuestionResponse[] {
  try {
    const data = localStorage.getItem("interview_questions");
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error("Failed to read local questions:", e);
    return [];
  }
}

// Helper: Set local questions to localStorage
function saveLocalQuestions(questions: InterviewQuestionResponse[]) {
  try {
    localStorage.setItem("interview_questions", JSON.stringify(questions));
  } catch (e) {
    console.error("Failed to save local questions:", e);
  }
}

// 1. Fetch Sessions
export async function dbFetchSessions(userId: string): Promise<InterviewSession[]> {
  if (isGuestUser(userId)) {
    // Return local sessions sorted by createdAt desc
    const local = getLocalSessions();
    return local
      .filter((s) => s.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  try {
    const q = query(
      collection(db, "sessions"),
      where("userId", "==", userId),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    const fetched: InterviewSession[] = [];
    querySnapshot.forEach((doc) => {
      fetched.push({ id: doc.id, ...doc.data() } as InterviewSession);
    });
    return fetched;
  } catch (error) {
    console.error("Firestore fetch sessions failed, falling back to local storage:", error);
    // Fallback to local storage
    const local = getLocalSessions();
    return local
      .filter((s) => s.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
}

// 2. Create Session
export async function dbCreateSession(userId: string, sessionData: Omit<InterviewSession, 'id'>): Promise<string> {
  if (isGuestUser(userId)) {
    const local = getLocalSessions();
    const newId = "local_sess_" + Math.random().toString(36).substring(2, 15);
    const newSession: InterviewSession = {
      id: newId,
      ...sessionData
    };
    local.push(newSession);
    saveLocalSessions(local);
    return newId;
  }

  try {
    const docRef = await addDoc(collection(db, "sessions"), sessionData);
    return docRef.id;
  } catch (error) {
    console.error("Firestore create session failed, saving locally:", error);
    const local = getLocalSessions();
    const newId = "local_sess_" + Math.random().toString(36).substring(2, 15);
    const newSession: InterviewSession = {
      id: newId,
      ...sessionData
    };
    local.push(newSession);
    saveLocalSessions(local);
    return newId;
  }
}

// 3. Create Question
export async function dbCreateQuestion(userId: string, questionData: Omit<InterviewQuestionResponse, 'id'>): Promise<string> {
  if (isGuestUser(userId)) {
    const local = getLocalQuestions();
    const newId = "local_q_" + Math.random().toString(36).substring(2, 15);
    const newQuestion: InterviewQuestionResponse = {
      id: newId,
      ...questionData
    };
    local.push(newQuestion);
    saveLocalQuestions(local);
    return newId;
  }

  try {
    const docRef = await addDoc(collection(db, "questions"), questionData);
    return docRef.id;
  } catch (error) {
    console.error("Firestore create question failed, saving locally:", error);
    const local = getLocalQuestions();
    const newId = "local_q_" + Math.random().toString(36).substring(2, 15);
    const newQuestion: InterviewQuestionResponse = {
      id: newId,
      ...questionData
    };
    local.push(newQuestion);
    saveLocalQuestions(local);
    return newId;
  }
}

// 4. Fetch Session by ID
export async function dbFetchSessionById(sessionId: string): Promise<InterviewSession | null> {
  if (sessionId.startsWith("local_sess_")) {
    const local = getLocalSessions();
    const found = local.find((s) => s.id === sessionId);
    return found || null;
  }

  try {
    const sessionRef = doc(db, "sessions", sessionId);
    const sessionSnap = await getDoc(sessionRef);
    if (sessionSnap.exists()) {
      return { id: sessionSnap.id, ...sessionSnap.data() } as InterviewSession;
    }
    // Try local as a secondary backup
    const local = getLocalSessions();
    const found = local.find((s) => s.id === sessionId);
    return found || null;
  } catch (error) {
    console.error("Firestore fetch session by id failed, checking local:", error);
    const local = getLocalSessions();
    const found = local.find((s) => s.id === sessionId);
    return found || null;
  }
}

// 5. Fetch Questions by Session ID
export async function dbFetchQuestionsBySessionId(sessionId: string): Promise<InterviewQuestionResponse[]> {
  if (sessionId.startsWith("local_sess_")) {
    const local = getLocalQuestions();
    return local
      .filter((q) => q.sessionId === sessionId)
      .sort((a, b) => a.index - b.index);
  }

  try {
    const qQuery = query(collection(db, "questions"), where("sessionId", "==", sessionId));
    const qSnap = await getDocs(qQuery);
    const fetchedQuestions: InterviewQuestionResponse[] = [];
    qSnap.forEach((doc) => {
      fetchedQuestions.push({ id: doc.id, ...doc.data() } as InterviewQuestionResponse);
    });
    fetchedQuestions.sort((a, b) => a.index - b.index);
    return fetchedQuestions;
  } catch (error) {
    console.error("Firestore fetch questions failed, checking local:", error);
    const local = getLocalQuestions();
    return local
      .filter((q) => q.sessionId === sessionId)
      .sort((a, b) => a.index - b.index);
  }
}

// 6. Update Question
export async function dbUpdateQuestion(questionId: string, updates: Partial<InterviewQuestionResponse>): Promise<void> {
  if (questionId.startsWith("local_q_")) {
    const local = getLocalQuestions();
    const index = local.findIndex((q) => q.id === questionId);
    if (index !== -1) {
      local[index] = { ...local[index], ...updates };
      saveLocalQuestions(local);
    }
    return;
  }

  try {
    const qRef = doc(db, "questions", questionId);
    await updateDoc(qRef, updates);
  } catch (error) {
    console.error("Firestore update question failed, updating locally:", error);
    const local = getLocalQuestions();
    const index = local.findIndex((q) => q.id === questionId);
    if (index !== -1) {
      local[index] = { ...local[index], ...updates };
      saveLocalQuestions(local);
    }
  }
}

// 7. Update Session
export async function dbUpdateSession(sessionId: string, updates: Partial<InterviewSession>): Promise<void> {
  if (sessionId.startsWith("local_sess_")) {
    const local = getLocalSessions();
    const index = local.findIndex((s) => s.id === sessionId);
    if (index !== -1) {
      local[index] = { ...local[index], ...updates };
      saveLocalSessions(local);
    }
    return;
  }

  try {
    const sRef = doc(db, "sessions", sessionId);
    await updateDoc(sRef, updates);
  } catch (error) {
    console.error("Firestore update session failed, updating locally:", error);
    const local = getLocalSessions();
    const index = local.findIndex((s) => s.id === sessionId);
    if (index !== -1) {
      local[index] = { ...local[index], ...updates };
      saveLocalSessions(local);
    }
  }
}
