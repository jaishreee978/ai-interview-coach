import { useState, useEffect, useRef } from "react";
import { 
  Mic, 
  MicOff, 
  Volume2, 
  Send, 
  ArrowRight, 
  Award, 
  CheckCircle2, 
  ChevronRight, 
  Sparkles, 
  Brain, 
  MessageSquare, 
  XCircle, 
  RotateCcw,
  BookOpen,
  ArrowLeft,
  VolumeX
} from "lucide-react";
import { dbFetchSessionById, dbFetchQuestionsBySessionId, dbUpdateQuestion, dbUpdateSession } from "../dbHelper";
import { InterviewSession, InterviewQuestionResponse } from "../types";

interface InterviewStageProps {
  userId: string;
  sessionId: string;
  onExit: () => void;
  onCompleted: (sessionId: string) => void;
}

export default function InterviewStage({ userId, sessionId, onExit, onCompleted }: InterviewStageProps) {
  const [session, setSession] = useState<InterviewSession | null>(null);
  const [questions, setQuestions] = useState<InterviewQuestionResponse[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [submittingAnswer, setSubmittingAnswer] = useState(false);
  const [compilingFeedback, setCompilingFeedback] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Input states
  const [userAnswerText, setUserAnswerText] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recognitionSupported, setRecognitionSupported] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Audio/TTS state
  const [isPlayingTTS, setIsPlayingTTS] = useState(false);
  const [isAutoSpeak, setIsAutoSpeak] = useState(true);

  // Fetch Session & Questions
  useEffect(() => {
    async function fetchInterviewData() {
      try {
        // 1. Fetch Session
        const sData = await dbFetchSessionById(sessionId);
        if (!sData) {
          throw new Error("Interview session not found.");
        }
        setSession(sData);

        // 2. Fetch Questions
        const fetchedQuestions = await dbFetchQuestionsBySessionId(sessionId);
        setQuestions(fetchedQuestions);

        // Set current index to the first unanswered question
        const firstUnanswered = fetchedQuestions.findIndex(q => !q.isAnswered);
        if (firstUnanswered !== -1) {
          setCurrentIndex(firstUnanswered);
        } else {
          setCurrentIndex(fetchedQuestions.length - 1);
        }
      } catch (err: any) {
        console.error("Error loading interview:", err);
        setError(err.message || "Failed to load session details.");
      } finally {
        setLoading(false);
      }
    }

    if (sessionId) {
      fetchInterviewData();
    }
  }, [sessionId]);

  // Speech Recognition Setup
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      setRecognitionSupported(true);
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = "en-US";

      rec.onresult = (event: any) => {
        let interimTranscript = "";
        let finalTranscript = "";

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (finalTranscript) {
          setUserAnswerText(prev => prev + (prev.endsWith(" ") || prev === "" ? "" : " ") + finalTranscript);
        }
      };

      rec.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        setIsRecording(false);
      };

      rec.onend = () => {
        setIsRecording(false);
      };

      recognitionRef.current = rec;
    }
  }, []);

  // Auto-speak question on index change
  const currentQuestion = questions[currentIndex];
  useEffect(() => {
    if (currentQuestion && isAutoSpeak && !loading) {
      // Small delay to ensure render is complete
      const timer = setTimeout(() => {
        speakText(currentQuestion.question);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [currentIndex, currentQuestion, loading]);

  // Handle Speech Recognition Toggle
  function toggleRecording() {
    if (!recognitionSupported || !recognitionRef.current) return;

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      setIsRecording(true);
      recognitionRef.current.start();
    }
  }

  // Speak text using Web Speech Synthesis
  function speakText(text: string) {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel(); // Cancel active speeches
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onstart = () => setIsPlayingTTS(true);
      utterance.onend = () => setIsPlayingTTS(false);
      utterance.onerror = () => setIsPlayingTTS(false);
      
      // Select an elegant English voice if available
      const voices = window.speechSynthesis.getVoices();
      const elegantVoice = voices.find(v => v.lang.startsWith("en") && (v.name.includes("Google") || v.name.includes("Natural")));
      if (elegantVoice) {
        utterance.voice = elegantVoice;
      }
      
      window.speechSynthesis.speak(utterance);
    }
  }

  function stopTTS() {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setIsPlayingTTS(false);
    }
  }

  // Submit Answer to analysis endpoint
  async function handleAnalyzeAnswer() {
    if (!currentQuestion) return;
    if (!userAnswerText.trim()) {
      setError("Please type or speak your response before submitting.");
      return;
    }

    setError(null);
    setSubmittingAnswer(true);
    stopTTS();

    // Stop recording if active
    if (isRecording && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsRecording(false);
    }

    try {
      const response = await fetch("/api/analyze-answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: currentQuestion.question,
          userAnswer: userAnswerText,
          category: currentQuestion.category,
          role: session?.role
        })
      });

      if (!response.ok) {
        throw new Error("Failed to evaluate answer. Please try again.");
      }

      const feedback = await response.json();

      const currentQuestionId = questions[currentIndex]?.id;
      if (!currentQuestionId) {
        throw new Error("Question record not found in state.");
      }
      
      const updateData = {
        userAnswer: userAnswerText,
        isAnswered: true,
        answeredAt: new Date().toISOString(),
        feedback
      };

      await dbUpdateQuestion(currentQuestionId, updateData);

      // Update local state
      setQuestions(prev => {
        const next = [...prev];
        next[currentIndex] = {
          ...next[currentIndex],
          ...updateData
        };
        return next;
      });

    } catch (err: any) {
      console.error("Error analyzing answer:", err);
      setError(err.message || "Analysis failed.");
    } finally {
      setSubmittingAnswer(false);
    }
  }

  // Proceed to next question or complete interview
  async function handleNext() {
    setError(null);
    if (currentIndex < questions.length - 1) {
      setUserAnswerText("");
      setCurrentIndex(prev => prev + 1);
    } else {
      // Finished all questions! Compile overall coaching feedback
      setCompilingFeedback(true);
      stopTTS();

      try {
        const activeResponses = questions.filter(q => q.isAnswered);
        
        const response = await fetch("/api/generate-overall-feedback", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            role: session?.role,
            company: session?.company,
            experienceLevel: session?.experienceLevel,
            responses: activeResponses
          })
        });

        if (!response.ok) {
          throw new Error("Failed to compile overall performance feedback.");
        }

        const overallFeedback = await response.json();

        // Save session overall feedback to DB
        const updateSessionData = {
          status: "completed" as const,
          score: overallFeedback.score,
          feedback: overallFeedback.feedback,
          categoryScores: overallFeedback.categoryScores
        };

        await dbUpdateSession(sessionId, updateSessionData);

        onCompleted(sessionId);
      } catch (err: any) {
        console.error("Error compiling final interview review:", err);
        setError(err.message || "Failed to compile final review. Please try again.");
      } finally {
        setCompilingFeedback(false);
      }
    }
  }

  // Restart answering the current question (clear text & state)
  function handleResetCurrent() {
    setUserAnswerText("");
    setError(null);
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-24 space-y-4">
        <div className="w-12 h-12 rounded-full border-4 border-cyan-500 border-t-transparent animate-spin shadow-[0_0_15px_rgba(6,182,212,0.4)]"></div>
        <div className="text-center">
          <p className="font-semibold text-white">Loading Live Interview Stage...</p>
          <p className="text-xs text-slate-500 font-mono">Connecting Firestore channel...</p>
        </div>
      </div>
    );
  }

  if (!session || questions.length === 0) {
    return (
      <div className="text-center p-12 space-y-4 rounded-2xl border border-white/5 bg-[#07090D] shadow-xl">
        <XCircle className="mx-auto text-rose-500 animate-pulse" size={48} />
        <h3 className="text-xl font-bold text-white">Oops! Load Error</h3>
        <p className="text-slate-400 text-sm font-light">Failed to retrieve questions for this interview session.</p>
        <button onClick={onExit} className="px-5 py-2.5 bg-slate-900 border border-white/5 hover:bg-slate-800 rounded-xl text-white transition-all">
          Return to Dashboard
        </button>
      </div>
    );
  }

  const progressPercentage = Math.round(((currentIndex + (currentQuestion?.isAnswered ? 1 : 0)) / questions.length) * 100);

  return (
    <div className="grid gap-6 lg:grid-cols-12 max-w-7xl mx-auto items-stretch" id="interview-stage-container">
      
      {/* LEFT COLUMN: Real-time Analytics Sidebar */}
      <aside className="lg:col-span-3 border border-white/5 bg-[#07090D] p-5 rounded-2xl flex flex-col gap-6" id="left-sidebar">
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mb-4 font-bold">Performance Pulse</h3>
          <div className="space-y-4">
            <div className="bg-white/5 rounded-xl p-4 border border-white/5">
              <div className="flex justify-between items-end mb-2">
                <span className="text-xs text-slate-400">Confidence Score</span>
                <span className="text-lg font-mono text-cyan-400 font-bold">
                  {currentIndex > 0 ? `${Math.round(questions.filter((q, idx) => idx < currentIndex && q.isAnswered).reduce((acc, cur) => acc + (cur.feedback?.score || 0), 0) / (questions.filter((q, idx) => idx < currentIndex && q.isAnswered).length || 1))}%` : "84%"}
                </span>
              </div>
              <div className="h-1.5 w-full bg-slate-850 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.6)] transition-all duration-500" 
                  style={{ width: currentIndex > 0 ? `${Math.round(questions.filter((q, idx) => idx < currentIndex && q.isAnswered).reduce((acc, cur) => acc + (cur.feedback?.score || 0), 0) / (questions.filter((q, idx) => idx < currentIndex && q.isAnswered).length || 1))}%` : "84%" }}
                ></div>
              </div>
            </div>
            
            <div className="bg-white/5 rounded-xl p-4 border border-white/5">
              <div className="flex justify-between items-end mb-2">
                <span className="text-xs text-slate-400">Speech Clarity</span>
                <span className={`text-lg font-mono font-bold ${isRecording ? "text-emerald-400 animate-pulse" : "text-slate-500"}`}>
                  {isRecording ? "Active" : "Ready"}
                </span>
              </div>
              <div className="flex gap-1 h-8 items-end">
                <div className={`w-full bg-emerald-500/30 rounded-t-sm transition-all duration-300 ${isRecording ? "h-[70%] animate-pulse" : "h-[15%]"}`}></div>
                <div className={`w-full bg-emerald-500/30 rounded-t-sm transition-all duration-300 ${isRecording ? "h-[90%] animate-pulse" : "h-[30%]"}`}></div>
                <div className={`w-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)] rounded-t-sm transition-all duration-300 ${isRecording ? "h-[50%] animate-pulse" : "h-[20%]"}`}></div>
                <div className={`w-full bg-emerald-500/30 rounded-t-sm transition-all duration-300 ${isRecording ? "h-[80%] animate-pulse" : "h-[40%]"}`}></div>
                <div className={`w-full bg-emerald-500/30 rounded-t-sm transition-all duration-300 ${isRecording ? "h-[60%] animate-pulse" : "h-[10%]"}`}></div>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mb-3 font-bold">Extracted Keywords</h3>
          <div className="flex flex-wrap gap-1.5">
            <span className="px-2.5 py-1 rounded bg-blue-500/10 border border-blue-500/20 text-[10px] text-blue-300">STAR Method</span>
            <span className="px-2.5 py-1 rounded bg-cyan-500/10 border border-cyan-500/20 text-[10px] text-cyan-300">Action Oriented</span>
            <span className="px-2.5 py-1 rounded bg-slate-500/10 border border-slate-500/20 text-[10px] text-slate-400 font-mono">Clarity Focus</span>
            {session.company && (
              <span className="px-2.5 py-1 rounded bg-emerald-500/10 border border-emerald-500/20 text-[10px] text-emerald-300 font-sans">{session.company} Target</span>
            )}
          </div>
        </div>

        <div className="mt-auto">
          <div className="bg-gradient-to-b from-blue-600/10 to-transparent border-t border-blue-500/20 p-4 rounded-t-2xl">
            <p className="text-xs font-semibold text-blue-300 mb-1 italic">Coach Tip:</p>
            <p className="text-[11px] text-slate-400 leading-relaxed font-light">
              {currentIndex === 0 
                ? "Start with a strong hook! Use the STAR method to describe Situation, Task, Action, and Results clearly." 
                : "Remember to quantify your results if possible. E.g., 'reduced latency by 40%' or 'managed 5 team members'."}
            </p>
          </div>
        </div>
      </aside>

      {/* CENTRAL COLUMN: Simulation Stage */}
      <section className="lg:col-span-6 flex flex-col justify-between space-y-4" id="central-stage">
        {/* Header bar */}
        <div className="flex items-center justify-between p-3.5 rounded-xl border border-white/5 bg-[#0A0C10]/60 backdrop-blur-md">
          <button 
            onClick={onExit}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer font-light"
          >
            <ArrowLeft size={13} /> Exit
          </button>
          
          <div className="text-center">
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold block">SIMULATION ACTIVE</span>
            <span className="text-xs font-bold text-cyan-400 truncate max-w-[180px] inline-block">{session.role}</span>
          </div>

          <div className="text-right text-xs font-mono text-slate-400">
            [ {currentIndex + 1} / {questions.length} ]
          </div>
        </div>

        {/* Dynamic Completion Line */}
        <div className="space-y-1 px-1">
          <div className="flex justify-between text-[10px] text-slate-500 font-mono uppercase tracking-wider">
            <span>Interview Completion</span>
            <span>{progressPercentage}%</span>
          </div>
          <div className="h-1 w-full bg-[#07090D] rounded-full overflow-hidden border border-white/5">
            <div 
              className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 transition-all duration-500 rounded-full shadow-[0_0_8px_#06b6d4]" 
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
        </div>

        {/* AI Avatar View */}
        <div className="relative rounded-2xl border border-white/5 bg-gradient-to-b from-[#0F1219] to-[#050608] p-6 flex flex-col items-center justify-center overflow-hidden min-h-[280px]">
          {/* Deep shadows and glows for the AI persona */}
          <div className="absolute inset-0 bg-cyan-500/5 blur-[80px] rounded-full"></div>
          <div className={`relative w-36 h-36 rounded-full bg-[#121620] border border-white/10 flex items-center justify-center z-10 shadow-2xl transition-all duration-500 ${isPlayingTTS ? 'shadow-[0_0_30px_rgba(6,182,212,0.25)] border-cyan-500/40 scale-105' : ''}`}>
             <div className="absolute inset-0 bg-gradient-to-tr from-cyan-950/25 to-transparent"></div>
             <div className={`w-24 h-24 rounded-full border border-cyan-500/20 flex items-center justify-center ${isPlayingTTS ? 'animate-pulse' : ''}`}>
                <div className="w-16 h-16 rounded-full border border-cyan-400/15 flex items-center justify-center">
                   <Brain className={`w-7 h-7 text-cyan-400 ${isPlayingTTS ? 'animate-bounce' : ''}`} />
                </div>
             </div>
          </div>
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-cyan-500 text-black text-[9px] font-black px-2.5 py-0.5 rounded uppercase tracking-widest shadow-md">
            {isPlayingTTS ? "Speaking" : isRecording ? "Listening" : "Analyzing"}
          </div>
        </div>

        {/* Question Text block */}
        <div className="text-center max-w-xl mx-auto px-4 py-2 space-y-2">
          <div className="flex justify-center items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/20 text-[9px] text-cyan-300 font-semibold uppercase tracking-wider font-mono">
              {currentQuestion.category} Question
            </span>
            
            {/* Audio actions */}
            <button
              type="button"
              onClick={() => speakText(currentQuestion.question)}
              className={`p-1.5 rounded-lg border transition-all cursor-pointer ${isPlayingTTS ? 'bg-cyan-500/15 text-cyan-400 border-cyan-500/40' : 'bg-white/5 text-slate-400 border-white/5 hover:border-cyan-500/20'}`}
              title="Speak Question"
            >
              <Volume2 size={12} />
            </button>
            {isPlayingTTS && (
              <button
                type="button"
                onClick={stopTTS}
                className="p-1.5 rounded-lg border bg-rose-500/10 text-rose-400 border-rose-500/20 hover:bg-rose-500/30 transition-all cursor-pointer"
                title="Stop TTS"
              >
                <VolumeX size={12} />
              </button>
            )}
          </div>
          <h2 className="text-base md:text-lg font-light text-slate-200 leading-relaxed">
            “{currentQuestion.question}”
          </h2>
        </div>

        {/* Answer input container */}
        <div className="space-y-3 bg-[#0A0C10]/40 p-4 rounded-xl border border-white/5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Live Answer Input</span>
            <div className="flex items-center gap-1.5">
              {recognitionSupported ? (
                <button
                  type="button"
                  onClick={toggleRecording}
                  id="toggle-mic-btn"
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${isRecording ? 'bg-rose-500/20 text-rose-450 border-rose-500/40 animate-pulse' : 'bg-cyan-500/10 text-cyan-450 border-cyan-500/20 hover:bg-cyan-500/20'}`}
                >
                  <Mic size={11} />
                  <span>{isRecording ? "Stop Speech" : "Use Mic"}</span>
                </button>
              ) : null}
              {userAnswerText && (
                <button
                  type="button"
                  onClick={handleResetCurrent}
                  className="p-1 text-slate-500 hover:text-slate-300 transition-colors"
                  title="Clear text"
                >
                  <RotateCcw size={11} />
                </button>
              )}
            </div>
          </div>

          <div className="relative">
            <textarea
              value={userAnswerText}
              onChange={(e) => setUserAnswerText(e.target.value)}
              disabled={currentQuestion.isAnswered || submittingAnswer}
              placeholder="Speak your response using 'Use Mic' or type your details directly here..."
              rows={4}
              className="w-full p-3 bg-[#050608] border border-white/5 rounded-xl text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500/30 text-xs leading-relaxed transition-all resize-none"
            />
            {isRecording && (
              <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-rose-500/10 border border-rose-500/20 px-2 py-1 rounded-lg text-[10px] text-rose-450 font-bold font-mono">
                <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-ping"></span>
                Transcribing...
              </div>
            )}
          </div>

          {error && (
            <div className="rounded-xl bg-rose-500/10 border border-rose-500/20 p-3 text-xs text-rose-400 font-light">
              {error}
            </div>
          )}

          {/* Primary Action Button */}
          {!currentQuestion.isAnswered ? (
            <button
              type="button"
              onClick={handleAnalyzeAnswer}
              disabled={submittingAnswer || !userAnswerText.trim()}
              id="submit-answer-btn"
              className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-black bg-cyan-500 hover:bg-cyan-400 hover:shadow-[0_0_15px_rgba(6,182,212,0.35)] transition-all cursor-pointer disabled:bg-slate-900 disabled:text-slate-600 disabled:shadow-none"
            >
              {submittingAnswer ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-black border-t-transparent animate-spin"></div>
                  <span>Evaluating answer structure...</span>
                </>
              ) : (
                <>
                  <Send size={14} />
                  <span>Evaluate Response</span>
                </>
              )}
            </button>
          ) : (
            <button
              type="button"
              onClick={handleNext}
              disabled={compilingFeedback}
              id="next-question-btn"
              className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-black bg-cyan-500 hover:bg-cyan-400 hover:shadow-[0_0_15px_rgba(6,182,212,0.35)] transition-all cursor-pointer"
            >
              {compilingFeedback ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-black border-t-transparent animate-spin"></div>
                  <span>Compiling overall review...</span>
                </>
              ) : (
                <>
                  <span>{currentIndex < questions.length - 1 ? "Next Question" : "Finish Interview"}</span>
                  <ChevronRight size={14} />
                </>
              )}
            </button>
          )}
        </div>
      </section>

      {/* RIGHT COLUMN: Real-time Evaluation Panel */}
      <aside className="lg:col-span-3 bg-[#0A0C10] border border-white/5 rounded-2xl flex flex-col justify-between overflow-hidden" id="right-sidebar">
        
        {/* Header tabs */}
        <div className="p-4 border-b border-white/5 flex justify-between items-center bg-black/25">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Live Assessment</span>
          <span className="px-1.5 py-0.5 rounded bg-cyan-500/10 text-[9px] text-cyan-400 font-bold uppercase tracking-widest font-mono">REALTIME</span>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-4 space-y-4 overflow-y-auto max-h-[380px]">
          {!currentQuestion.isAnswered ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-4 space-y-3">
              <div className="p-3 bg-white/5 border border-white/5 text-slate-500 rounded-2xl animate-pulse">
                <Sparkles size={24} />
              </div>
              <div className="space-y-1">
                <h4 className="font-semibold text-slate-300 text-xs">Awaiting Submission</h4>
                <p className="text-[11px] text-slate-500 leading-normal font-light">
                  Submit your response to see instant coaching evaluation, STAR alignment, and customized feedback.
                </p>
              </div>
            </div>
          ) : currentQuestion.feedback ? (
            <div className="space-y-4">
              {/* Score card */}
              <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
                <div>
                  <span className="text-[9px] text-slate-500 uppercase tracking-wider block font-mono">Score</span>
                  <span className="font-mono text-cyan-400 font-bold text-xl">{currentQuestion.feedback.score}%</span>
                </div>
                <div className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${currentQuestion.feedback.score >= 80 ? 'bg-emerald-500/15 text-emerald-450' : 'bg-amber-500/15 text-amber-450'}`}>
                  {currentQuestion.feedback.score >= 80 ? 'Exceptional' : 'Good'}
                </div>
              </div>

              {/* Pros & Cons list */}
              <div className="space-y-3 text-[11px]">
                <div className="space-y-1">
                  <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest block font-mono">Strengths</span>
                  <ul className="text-slate-300 space-y-1 list-disc pl-3">
                    {currentQuestion.feedback.pros.slice(0, 2).map((p, idx) => (
                      <li key={idx} className="font-light">{p}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-1">
                  <span className="text-[9px] font-bold text-rose-400 uppercase tracking-widest block font-mono">Improvements</span>
                  <ul className="text-slate-300 space-y-1 list-disc pl-3">
                    {currentQuestion.feedback.cons.slice(0, 2).map((c, idx) => (
                      <li key={idx} className="font-light">{c}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Delivery Tip */}
              <div className="p-3 rounded-lg bg-[#07090D] border border-white/5">
                <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-widest block mb-1 font-mono">Communication Tip</span>
                <p className="text-[11px] text-slate-400 leading-normal font-light">
                  {currentQuestion.feedback.communicationFeedback}
                </p>
              </div>

              {/* Guide Response */}
              <div className="p-3 rounded-lg bg-cyan-950/10 border border-cyan-500/10">
                <span className="text-[9px] font-bold text-slate-300 uppercase tracking-widest block mb-1 font-mono">Model Guide</span>
                <p className="text-[11px] text-slate-300 italic leading-relaxed font-light">
                  "{currentQuestion.feedback.betterResponse.substring(0, 160)}..."
                </p>
              </div>
            </div>
          ) : null}
        </div>

        {/* Goals area */}
        <div className="p-4 bg-black/40 border-t border-white/5 text-[11px] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-bold uppercase tracking-wider text-slate-500 font-mono">SESSION GOALS</span>
            <span className="text-xs font-mono text-cyan-400">
              {questions.filter(q => q.isAnswered).length} / {questions.length} Done
            </span>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-450">
              <div className="w-3.5 h-3.5 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <CheckCircle2 size={10} className="text-emerald-450" />
              </div>
              <span className="font-light">STAR Structure Applied</span>
            </div>
            <div className="flex items-center gap-2 text-emerald-455">
              <div className="w-3.5 h-3.5 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <CheckCircle2 size={10} className="text-emerald-455" />
              </div>
              <span className="font-light">Active Vocabulary Check</span>
            </div>
            <div className={`flex items-center gap-2 ${currentIndex > 0 ? "text-emerald-400" : "text-slate-500"}`}>
              {currentIndex > 0 ? (
                <div className="w-3.5 h-3.5 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                  <CheckCircle2 size={10} />
                </div>
              ) : (
                <div className="w-3.5 h-3.5 rounded-full border border-slate-800"></div>
              )}
              <span className="font-light">Quantified Results Shown</span>
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
}
