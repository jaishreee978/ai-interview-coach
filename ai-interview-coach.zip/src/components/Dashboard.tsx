import { useState, useEffect } from "react";
import { 
  TrendingUp, 
  Award, 
  Clock, 
  ChevronRight, 
  Brain, 
  Sparkles, 
  Plus, 
  BookOpen, 
  User 
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from "recharts";
import { dbFetchSessions } from "../dbHelper";
import { InterviewSession } from "../types";

interface DashboardProps {
  userId: string;
  onStartNew: () => void;
  onSelectSession: (sessionId: string) => void;
}

export default function Dashboard({ userId, onStartNew, onSelectSession }: DashboardProps) {
  const [sessions, setSessions] = useState<InterviewSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchSessions() {
      try {
        const fetched = await dbFetchSessions(userId);
        setSessions(fetched);
      } catch (error) {
        console.error("Error fetching sessions:", error);
      } finally {
        setLoading(false);
      }
    }
    if (userId) {
      fetchSessions();
    }
  }, [userId]);

  // Statistics
  const completedSessions = sessions.filter(s => s.status === "completed");
  const totalCompleted = completedSessions.length;
  
  const avgScore = totalCompleted > 0
    ? Math.round(completedSessions.reduce((acc, s) => acc + (s.score || 0), 0) / totalCompleted)
    : 0;

  // Best domain score category helper
  const categoryAverages = completedSessions.reduce((acc, s) => {
    if (s.categoryScores) {
      Object.entries(s.categoryScores).forEach(([cat, val]) => {
        if (typeof val === "number") {
          acc[cat] = (acc[cat] || { sum: 0, count: 0 });
          acc[cat].sum += val;
          acc[cat].count += 1;
        }
      });
    }
    return acc;
  }, {} as Record<string, { sum: number; count: number }>);

  const parsedCategoryData = Object.entries(categoryAverages).map(([cat, info]) => {
    const averageInfo = info as { sum: number; count: number };
    return {
      name: cat.charAt(0).toUpperCase() + cat.slice(1),
      score: Math.round(averageInfo.sum / averageInfo.count)
    };
  });

  const strongestCategory = parsedCategoryData.length > 0
    ? parsedCategoryData.reduce((prev, current) => (prev.score > current.score) ? prev : current).name
    : "N/A";

  // Chart data: chronological progress
  const chartData = [...completedSessions]
    .reverse()
    .map(s => ({
      date: new Date(s.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      score: s.score || 0,
      role: s.role
    }));

  const BAR_COLORS = ["#06b6d4", "#3b82f6", "#10b981", "#8b5cf6"];

  return (
    <div className="space-y-8" id="dashboard-container">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0A0C10] to-[#050608] p-8 border border-white/5 shadow-[0_0_30px_rgba(6,182,212,0.1)]">
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-900/10 via-transparent to-transparent"></div>
        <div className="absolute top-0 right-0 p-4 opacity-5">
          <Brain size={180} className="text-cyan-400" />
        </div>
        <div className="relative z-10 max-w-2xl space-y-4">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-cyan-500/10 px-3 py-1 text-xs font-semibold text-cyan-400 border border-cyan-500/20">
            <Sparkles size={12} /> Powered by Advanced Gemini NLP
          </span>
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            Ace Your Next Big Interview
          </h1>
          <p className="text-slate-400 text-base md:text-lg leading-relaxed font-light">
            Practice realistic AI-driven mock interviews customized to your target role, company, and seniority level. Get immediate, deep conversational and technical feedback.
          </p>
          <div className="pt-2">
            <button
              onClick={onStartNew}
              id="start-interview-hero-btn"
              className="inline-flex items-center gap-2 rounded-xl bg-cyan-500 px-6 py-3.5 text-sm font-bold text-black hover:bg-cyan-400 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] active:scale-95 transition-all cursor-pointer"
            >
              <Plus size={18} /> Start New Mock Session
            </button>
          </div>
        </div>
      </div>

      {/* Stats Bento Grid */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {/* Stat Card 1 */}
        <div className="rounded-2xl border border-white/5 bg-[#07090D] p-6 flex items-center justify-between shadow-md">
          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">Total Mock Sessions</span>
            <div className="text-3xl font-bold text-white font-mono">{sessions.length}</div>
            <p className="text-xs text-slate-500">{completedSessions.length} completed, {sessions.length - completedSessions.length} active</p>
          </div>
          <div className="p-3 bg-cyan-500/10 rounded-xl text-cyan-400 border border-cyan-500/10 shadow-[0_0_10px_rgba(6,182,212,0.1)]">
            <BookOpen size={24} />
          </div>
        </div>

        {/* Stat Card 2 */}
        <div className="rounded-2xl border border-white/5 bg-[#07090D] p-6 flex items-center justify-between shadow-md">
          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">Average Evaluation</span>
            <div className="text-3xl font-bold text-white font-mono">
              {totalCompleted > 0 ? `${avgScore}%` : "N/A"}
            </div>
            <div className="flex items-center gap-1">
              <span className={`h-1.5 w-1.5 rounded-full ${avgScore >= 80 ? 'bg-emerald-400' : avgScore >= 60 ? 'bg-amber-400' : 'bg-rose-400'}`}></span>
              <p className="text-xs text-slate-500">
                {avgScore >= 80 ? "Excellent standing" : avgScore >= 60 ? "Solid base, keep practicing" : totalCompleted === 0 ? "Evaluate now" : "Needs coaching"}
              </p>
            </div>
          </div>
          <div className="p-3 bg-blue-500/10 rounded-xl text-blue-400 border border-blue-500/10">
            <Award size={24} />
          </div>
        </div>

        {/* Stat Card 3 */}
        <div className="rounded-2xl border border-white/5 bg-[#07090D] p-6 flex items-center justify-between shadow-md">
          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">Strongest Domain</span>
            <div className="text-2xl font-bold text-white truncate max-w-[150px]">{strongestCategory}</div>
            <p className="text-xs text-slate-500">Based on recent metrics</p>
          </div>
          <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400 border border-indigo-500/10">
            <Brain size={24} />
          </div>
        </div>

        {/* Stat Card 4 */}
        <div className="rounded-2xl border border-white/5 bg-[#07090D] p-6 flex items-center justify-between shadow-md">
          <div className="space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">Recent Activity</span>
            <div className="text-base font-semibold text-white truncate max-w-[150px]">
              {sessions.length > 0 ? sessions[0].role : "No sessions yet"}
            </div>
            <p className="text-xs text-slate-500">
              {sessions.length > 0 
                ? new Date(sessions[0].createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) 
                : "Get started today!"}
            </p>
          </div>
          <div className="p-3 bg-purple-500/10 rounded-xl text-purple-400 border border-purple-500/10">
            <Clock size={24} />
          </div>
        </div>
      </div>

      {/* Charts section */}
      {totalCompleted > 0 && (
        <div className="grid gap-6 md:grid-cols-2">
          {/* Progress Chart */}
          <div className="rounded-2xl border border-white/5 bg-[#07090D] p-6 shadow-md flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <div className="space-y-1">
                <h3 className="font-bold text-white text-lg flex items-center gap-2">
                  <TrendingUp size={18} className="text-cyan-400" /> Score Progress
                </h3>
                <p className="text-slate-400 text-xs font-light">Visualizing performance across historical sessions</p>
              </div>
            </div>
            <div className="h-[220px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#161b22" />
                  <XAxis dataKey="date" stroke="#484f58" fontSize={11} tickLine={false} />
                  <YAxis domain={[0, 100]} stroke="#484f58" fontSize={11} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0d1117", borderColor: "rgba(255,255,255,0.05)", color: "#f0f6fc" }}
                    labelStyle={{ fontWeight: "bold", color: "#22d3ee" }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#06b6d4" 
                    strokeWidth={3} 
                    dot={{ fill: "#050608", stroke: "#06b6d4", strokeWidth: 2, r: 5 }} 
                    activeDot={{ r: 7, strokeWidth: 0, fill: "#22d3ee" }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Categories Bar Chart */}
          {parsedCategoryData.length > 0 && (
            <div className="rounded-2xl border border-white/5 bg-[#07090D] p-6 shadow-md flex flex-col justify-between">
              <div className="space-y-1 mb-4">
                <h3 className="font-bold text-white text-lg flex items-center gap-2">
                  <Brain size={18} className="text-indigo-400" /> Skill Breakdown
                </h3>
                <p className="text-slate-400 text-xs font-light">Average scores across core interview modules</p>
              </div>
              <div className="h-[220px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={parsedCategoryData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#161b22" />
                    <XAxis dataKey="name" stroke="#484f58" fontSize={11} tickLine={false} />
                    <YAxis domain={[0, 100]} stroke="#484f58" fontSize={11} tickLine={false} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: "#0d1117", borderColor: "rgba(255,255,255,0.05)", color: "#f0f6fc" }}
                    />
                    <Bar dataKey="score" radius={[4, 4, 0, 0]} barSize={32}>
                      {parsedCategoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={BAR_COLORS[index % BAR_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      )}

      {/* History Log */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <Clock size={18} className="text-slate-400" /> Session History
          </h2>
          {sessions.length > 0 && (
            <span className="text-xs text-slate-500 font-mono">
              [ {sessions.length} SESSIONS ]
            </span>
          )}
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center p-12 rounded-2xl border border-white/5 bg-[#07090D]/55 space-y-3">
            <div className="w-8 h-8 rounded-full border-2 border-cyan-500 border-t-transparent animate-spin shadow-[0_0_10px_rgba(6,182,212,0.2)]"></div>
            <span className="text-xs text-slate-500 font-mono">Syncing with Cloud Firestore...</span>
          </div>
        ) : sessions.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center p-12 rounded-2xl border border-white/5 border-dashed bg-[#07090D]/20 space-y-4">
            <div className="p-4 bg-[#0A0C10]/60 rounded-full text-slate-600 border border-white/5">
              <Clock size={32} />
            </div>
            <div className="space-y-1">
              <h3 className="font-semibold text-white">No Mock Interviews Found</h3>
              <p className="text-slate-450 text-xs max-w-sm font-light">
                Get started by setting up your first real-time interview customized to your target role.
              </p>
            </div>
            <button
              onClick={onStartNew}
              id="start-first-session-btn"
              className="inline-flex items-center gap-1.5 rounded-lg bg-cyan-500/10 px-4 py-2 text-xs font-semibold text-cyan-400 border border-cyan-500/20 hover:bg-cyan-500/20 active:scale-95 transition-all cursor-pointer"
            >
              Configure First Session
            </button>
          </div>
        ) : (
          <div className="grid gap-4">
            {sessions.map((session) => (
              <div
                key={session.id}
                onClick={() => onSelectSession(session.id)}
                className="group relative flex flex-col md:flex-row items-start md:items-center justify-between p-5 rounded-2xl border border-white/5 bg-[#07090D] hover:bg-[#0A0C10] hover:border-cyan-500/20 transition-all cursor-pointer shadow-sm"
              >
                <div className="space-y-2 md:space-y-1 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-bold text-white text-base group-hover:text-cyan-400 transition-colors">
                      {session.role}
                    </h3>
                    {session.company && (
                      <span className="rounded-md bg-white/5 px-2.5 py-0.5 text-xs text-slate-300 border border-white/5">
                        at {session.company}
                      </span>
                    )}
                    <span className="rounded-md bg-white/5 px-2.5 py-0.5 text-xs text-slate-300 border border-white/5">
                      {session.experienceLevel}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500">
                    <span>
                      {new Date(session.createdAt).toLocaleDateString(undefined, { 
                        weekday: 'short', 
                        month: 'short', 
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                    <span>•</span>
                    <span>{session.questionsCount} Questions</span>
                    <span>•</span>
                    <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 font-medium ${session.status === "completed" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/10" : "bg-amber-500/10 text-amber-400 border border-amber-500/10"}`}>
                      {session.status === "completed" ? "Completed" : "In Progress"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4 mt-4 md:mt-0 w-full md:w-auto justify-between md:justify-end border-t border-white/5 md:border-0 pt-3 md:pt-0">
                  {session.status === "completed" && session.score !== undefined ? (
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <span className="block text-[9px] text-slate-500 uppercase tracking-wider font-semibold">Evaluation</span>
                        <span className="font-bold text-cyan-400 text-lg font-mono">{session.score}%</span>
                      </div>
                      <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 font-black text-sm">
                        {session.score >= 80 ? "A" : session.score >= 75 ? "B+" : session.score >= 65 ? "B" : "C"}
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold bg-amber-500/5 px-3 py-1.5 rounded-lg border border-amber-500/10">
                      <Clock size={12} /> Resume Practice
                    </div>
                  )}
                  <ChevronRight size={16} className="text-slate-600 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all hidden md:block" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
