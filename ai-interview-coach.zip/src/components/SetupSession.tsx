import React, { useState } from "react";
import { 
  Plus, 
  Sparkles, 
  ArrowRight, 
  Briefcase, 
  Building2, 
  Layers, 
  HelpCircle,
  Brain
} from "lucide-react";
import { dbCreateSession, dbCreateQuestion } from "../dbHelper";
import { InterviewSession, InterviewQuestionResponse } from "../types";

interface SetupSessionProps {
  userId: string;
  onSessionCreated: (sessionId: string) => void;
  onCancel: () => void;
}

const COMMON_ROLES = [
  "Software Engineer",
  "Frontend Engineer",
  "Backend Developer",
  "Product Manager",
  "Data Scientist",
  "UX Designer",
  "Financial Analyst",
  "System Administrator"
];

const COMMON_COMPANIES = [
  "Google",
  "Meta",
  "Apple",
  "Amazon",
  "Microsoft",
  "Stripe",
  "Netflix",
  "OpenAI"
];

export default function SetupSession({ userId, onSessionCreated, onCancel }: SetupSessionProps) {
  const [role, setRole] = useState("");
  const [customRole, setCustomRole] = useState("");
  const [company, setCompany] = useState("");
  const [customCompany, setCustomCompany] = useState("");
  const [experienceLevel, setExperienceLevel] = useState<"Entry-Level" | "Mid-Level" | "Senior-Level">("Mid-Level");
  const [numQuestions, setNumQuestions] = useState(5);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const selectedRole = role === "custom" || !role ? customRole.trim() : role;
    const selectedCompany = company === "custom" || !company ? customCompany.trim() : company;

    if (!selectedRole) {
      setError("Please specify a target interview role.");
      return;
    }

    setLoading(true);

    try {
      // 1. Generate questions from the server-side Gemini API
      const response = await fetch("/api/generate-questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          role: selectedRole,
          company: selectedCompany,
          experienceLevel,
          numQuestions
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to generate questions");
      }

      const generatedQuestions = await response.json();
      
      if (!Array.isArray(generatedQuestions) || generatedQuestions.length === 0) {
        throw new Error("No questions were generated. Please try again.");
      }

      // 2. Create the Session in DB
      const sessionData = {
        userId,
        createdAt: new Date().toISOString(),
        role: selectedRole,
        company: selectedCompany,
        experienceLevel,
        status: "ongoing" as const,
        questionsCount: generatedQuestions.length
      };

      const sessionId = await dbCreateSession(userId, sessionData);

      // 3. Store each generated question in the DB 'questions' collection
      for (let i = 0; i < generatedQuestions.length; i++) {
        const qData = generatedQuestions[i];
        const questionObj = {
          userId,
          sessionId,
          index: i,
          question: qData.question,
          category: qData.category,
          isAnswered: false,
          userAnswer: ""
        };
        await dbCreateQuestion(userId, questionObj);
      }

      onSessionCreated(sessionId);
    } catch (err: any) {
      console.error("Error setting up interview:", err);
      setError(err.message || "Something went wrong while setting up the interview.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6" id="setup-session-container">
      {/* Title */}
      <div className="space-y-2">
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <Brain size={24} className="text-cyan-400" /> New Mock Interview Setup
        </h2>
        <p className="text-slate-400 text-sm font-light">
          Select your target parameters. Our Gemini NLP model will curate realistic, challenging, and highly context-aware interview questions.
        </p>
      </div>

      <div className="rounded-2xl border border-white/5 bg-[#07090D] p-6 md:p-8 shadow-[0_0_30px_rgba(6,182,212,0.05)]">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Target Role */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-slate-350 flex items-center gap-1.5">
              <Briefcase size={16} className="text-cyan-400" /> Target Role / Position
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {COMMON_ROLES.slice(0, 7).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => { setRole(r); setCustomRole(""); }}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${role === r ? 'bg-cyan-500/10 text-cyan-350 border-cyan-500/40' : 'bg-slate-900/40 text-slate-400 border-white/5 hover:border-cyan-500/20'}`}
                >
                  {r}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setRole("custom")}
                className={`px-3 py-2 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${role === "custom" ? 'bg-cyan-500/10 text-cyan-350 border-cyan-500/40' : 'bg-slate-900/40 text-slate-400 border-white/5 hover:border-cyan-500/20'}`}
              >
                Custom Role...
              </button>
            </div>

            {(role === "custom" || COMMON_ROLES.indexOf(role) === -1) && (
              <input
                type="text"
                value={customRole}
                onChange={(e) => setCustomRole(e.target.value)}
                placeholder="e.g. Lead Devops Engineer, HR Manager"
                className="w-full mt-2 px-4 py-3 bg-[#050608] border border-white/5 rounded-xl text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500/40 text-sm transition-all"
                required
              />
            )}
          </div>

          {/* Target Company */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-slate-355 flex items-center gap-1.5">
              <Building2 size={16} className="text-cyan-400" /> Target Company (Optional)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {COMMON_COMPANIES.slice(0, 7).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => { setCompany(c); setCustomCompany(""); }}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${company === c ? 'bg-cyan-500/10 text-cyan-350 border-cyan-500/40' : 'bg-slate-900/40 text-slate-400 border-white/5 hover:border-cyan-500/20'}`}
                >
                  {c}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setCompany("custom")}
                className={`px-3 py-2 rounded-xl text-xs font-semibold text-center border transition-all cursor-pointer ${company === "custom" ? 'bg-cyan-500/10 text-cyan-350 border-cyan-500/40' : 'bg-slate-900/40 text-slate-400 border-white/5 hover:border-cyan-500/20'}`}
              >
                Custom Brand...
              </button>
            </div>

            {(company === "custom" || COMMON_COMPANIES.indexOf(company) === -1) && (
              <input
                type="text"
                value={customCompany}
                onChange={(e) => setCustomCompany(e.target.value)}
                placeholder="e.g. Goldman Sachs, Local Startup"
                className="w-full mt-2 px-4 py-3 bg-[#050608] border border-white/5 rounded-xl text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500/40 text-sm transition-all"
              />
            )}
          </div>

          {/* Dual row: experience & count */}
          <div className="grid gap-6 sm:grid-cols-2">
            {/* Experience Level */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-slate-350 flex items-center gap-1.5">
                <Layers size={16} className="text-cyan-400" /> Seniority Level
              </label>
              <select
                value={experienceLevel}
                onChange={(e) => setExperienceLevel(e.target.value as any)}
                className="w-full px-4 py-3 bg-[#050608] border border-white/5 rounded-xl text-white focus:outline-none focus:border-cyan-500/40 text-sm transition-all"
              >
                <option value="Entry-Level" className="bg-[#07090D] text-slate-200">Entry-Level / Junior</option>
                <option value="Mid-Level" className="bg-[#07090D] text-slate-200">Mid-Level / Professional</option>
                <option value="Senior-Level" className="bg-[#07090D] text-slate-200">Senior / Tech Lead / Director</option>
              </select>
            </div>

            {/* Questions count */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-slate-350 flex items-center gap-1.5">
                <HelpCircle size={16} className="text-cyan-400" /> Number of Questions
              </label>
              <div className="flex gap-2">
                {[3, 5, 7].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setNumQuestions(num)}
                    className={`flex-1 py-3 rounded-xl text-sm font-semibold border transition-all cursor-pointer ${numQuestions === num ? 'bg-cyan-500/10 text-cyan-350 border-cyan-500/40' : 'bg-slate-900/40 text-slate-400 border-white/5 hover:border-cyan-500/20'}`}
                  >
                    {num} Qs
                  </button>
                ))}
              </div>
            </div>
          </div>

          {error && (
            <div className="rounded-xl bg-rose-500/10 border border-rose-500/20 p-4 text-xs font-medium text-rose-400 leading-normal">
              {error}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-4 pt-4 border-t border-white/5">
            <button
              type="button"
              onClick={onCancel}
              disabled={loading}
              className="flex-1 py-3.5 text-sm font-bold text-slate-400 rounded-xl bg-slate-900/20 hover:bg-slate-900/60 border border-white/5 hover:text-white transition-all cursor-pointer disabled:opacity-40"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              id="generate-interview-btn"
              className="flex-1 inline-flex items-center justify-center gap-2 py-3.5 text-sm font-bold text-black rounded-xl bg-cyan-500 hover:bg-cyan-400 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all cursor-pointer disabled:bg-cyan-700/50 disabled:text-cyan-950/60"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-black border-t-transparent animate-spin"></div>
                  <span>AI is composing questions...</span>
                </>
              ) : (
                <>
                  <Sparkles size={16} />
                  <span>Start Live Simulation</span>
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
