import { useState, useEffect } from "react";
import { 
  Award, 
  TrendingUp, 
  Brain, 
  MessageSquare, 
  CheckCircle2, 
  XCircle, 
  BookOpen, 
  Sparkles, 
  ChevronRight, 
  ChevronDown, 
  ArrowLeft,
  RefreshCw
} from "lucide-react";
import { 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar, 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell
} from "recharts";
import { dbFetchSessionById, dbFetchQuestionsBySessionId } from "../dbHelper";
import { InterviewSession, InterviewQuestionResponse } from "../types";

interface SessionReviewProps {
  userId: string;
  sessionId: string;
  onBackToDashboard: () => void;
  onRetake: () => void;
}

export default function SessionReview({ userId, sessionId, onBackToDashboard, onRetake }: SessionReviewProps) {
  const [session, setSession] = useState<InterviewSession | null>(null);
  const [questions, setQuestions] = useState<InterviewQuestionResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedQuestionId, setExpandedQuestionId] = useState<string | null>(null);

  useEffect(() => {
    async function loadReviewData() {
      try {
        // Fetch session
        const fetchedSession = await dbFetchSessionById(sessionId);
        if (!fetchedSession) {
          throw new Error("Session does not exist.");
        }
        setSession(fetchedSession);

        // Fetch questions
        const fetchedQuestions = await dbFetchQuestionsBySessionId(sessionId);
        setQuestions(fetchedQuestions);
        
        // Expand first question by default
        if (fetchedQuestions.length > 0) {
          setExpandedQuestionId(fetchedQuestions[0].id);
        }
      } catch (error) {
        console.error("Error loading session review data:", error);
      } finally {
        setLoading(false);
      }
    }
    if (sessionId) {
      loadReviewData();
    }
  }, [sessionId]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-24 space-y-4">
        <div className="w-12 h-12 rounded-full border-4 border-cyan-500 border-t-transparent animate-spin shadow-[0_0_15px_rgba(6,182,212,0.4)]"></div>
        <p className="font-semibold text-white">Assembling performance insights...</p>
        <p className="text-xs text-slate-500 font-mono">Compiling Gemini NLP feedback...</p>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="text-center p-12 space-y-4 rounded-2xl border border-white/5 bg-[#07090D] shadow-xl">
        <XCircle className="mx-auto text-rose-500 animate-pulse" size={48} />
        <h3 className="text-xl font-bold text-white">Review Unavailable</h3>
        <p className="text-slate-400 font-light text-sm">Failed to load the feedback details.</p>
        <button onClick={onBackToDashboard} className="px-5 py-2.5 bg-slate-900 border border-white/5 rounded-xl text-white hover:bg-slate-800 transition-all">
          Back to Dashboard
        </button>
      </div>
    );
  }

  // Categories scores for Radar Chart
  const radarData = [
    { subject: "Technical", score: session.categoryScores?.technical ?? 70, fullMark: 100 },
    { subject: "Communication", score: session.categoryScores?.communication ?? 75, fullMark: 100 },
    { subject: "Problem Solving", score: session.categoryScores?.problemSolving ?? 68, fullMark: 100 },
    { subject: "Situational", score: session.categoryScores?.situational ?? 72, fullMark: 100 }
  ];

  function toggleQuestionExpand(id: string) {
    setExpandedQuestionId(prev => prev === id ? null : id);
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto" id="session-review-container">
      {/* Header bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-white/5">
        <div className="space-y-1">
          <button 
            onClick={onBackToDashboard}
            className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-white transition-colors cursor-pointer font-light mb-1"
          >
            <ArrowLeft size={13} /> Back to Dashboard
          </button>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">
            Interview Performance Report
          </h2>
          <p className="text-xs text-slate-400 font-light">
            {session.role} • {session.experienceLevel} {session.company ? `• target company: ${session.company}` : ""}
          </p>
        </div>
        
        <div className="flex gap-3 w-full md:w-auto">
          <button
            onClick={onRetake}
            className="flex-1 md:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl border border-white/5 bg-[#0A0C10] text-slate-300 hover:text-white hover:border-white/10 transition-all cursor-pointer font-medium text-xs"
          >
            <RefreshCw size={13} /> Retake Practice
          </button>
          <button
            onClick={onBackToDashboard}
            className="flex-1 md:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-cyan-500 text-black font-extrabold hover:bg-cyan-400 hover:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all cursor-pointer text-xs"
          >
            Back to Home
          </button>
        </div>
      </div>

      {/* Main stats blocks */}
      <div className="grid gap-6 md:grid-cols-12">
        {/* Score Ring & Feedback Callout */}
        <div className="md:col-span-8 rounded-2xl border border-white/5 bg-[#07090D] p-6 md:p-8 space-y-6 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 p-6 opacity-[0.02] pointer-events-none">
            <Brain size={180} />
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-6 border-b border-white/5 z-10">
            <div className="space-y-2">
              <span className="inline-flex items-center gap-1 rounded-full bg-cyan-500/10 px-2.5 py-1 text-[10px] font-bold text-cyan-400 border border-cyan-400/25 uppercase tracking-widest font-mono">
                <Sparkles size={11} /> Review Compiled
              </span>
              <h3 className="text-xl font-bold text-white">Coaching Synthesis</h3>
              <p className="text-xs text-slate-400 font-light">Overall evaluations based on historical and communication parameters.</p>
            </div>

            {/* Score Ring */}
            <div className="flex items-center gap-5 bg-[#0A0C10] border border-white/5 px-4 py-3 rounded-2xl">
              <div className="relative flex items-center justify-center">
                {/* SVG Ring background */}
                <svg className="w-20 h-20 transform -rotate-90">
                  <circle cx="40" cy="40" r="34" stroke="rgba(255,255,255,0.02)" strokeWidth="6" fill="transparent" />
                  <circle cx="40" cy="40" r="34" stroke="#06b6d4" strokeWidth="6" fill="transparent" 
                    strokeDasharray={213.6}
                    strokeDashoffset={213.6 - (213.6 * (session.score || 0)) / 100}
                    strokeLinecap="round"
                    className="transition-all duration-1000 shadow-[0_0_10px_#06b6d4]"
                  />
                </svg>
                <div className="absolute flex flex-col items-center justify-center">
                  <span className="text-lg font-black text-white font-mono">{session.score}%</span>
                  <span className="text-[8px] uppercase tracking-wider font-bold text-slate-500">Score</span>
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Standing</div>
                <div className={`text-xs font-extrabold ${session.score && session.score >= 80 ? 'text-emerald-450' : session.score && session.score >= 65 ? 'text-amber-450' : 'text-rose-400'}`}>
                  {session.score && session.score >= 80 ? 'Elite (Offer Ready)' : session.score && session.score >= 65 ? 'Competitive Pass' : 'Requires Realignment'}
                </div>
              </div>
            </div>
          </div>

          {/* Coaching Paragraph */}
          <div className="space-y-3 pt-2 z-10">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 font-mono">
              <Brain size={13} className="text-cyan-400" /> Executive Coaching Summary
            </h4>
            <p className="text-slate-300 text-xs leading-relaxed whitespace-pre-line bg-black/30 p-5 rounded-xl border border-white/5 font-light">
              {session.feedback}
            </p>
          </div>
        </div>

        {/* Radar Chart category panel */}
        <div className="md:col-span-4 rounded-2xl border border-white/5 bg-[#07090D] p-6 flex flex-col justify-between shadow-md">
          <div className="space-y-1">
            <h3 className="font-bold text-white text-base">Competency Grid</h3>
            <p className="text-slate-400 text-xs font-light">Evaluations mapped onto hiring criteria</p>
          </div>

          <div className="h-[220px] w-full flex items-center justify-center py-2">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="65%" data={radarData}>
                <PolarGrid stroke="rgba(255,255,255,0.05)" />
                <PolarAngleAxis dataKey="subject" stroke="#64748b" fontSize={9} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#334155" fontSize={8} />
                <Radar 
                  name="Candidate" 
                  dataKey="score" 
                  stroke="#06b6d4" 
                  fill="#06b6d4" 
                  fillOpacity={0.15} 
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-4 border-t border-white/5">
            {radarData.map((d) => (
              <div key={d.subject} className="bg-white/5 p-2 rounded-lg border border-white/5 flex justify-between items-center">
                <span className="text-[9px] text-slate-400 font-semibold">{d.subject}</span>
                <span className="text-[11px] font-mono font-bold text-cyan-400">{d.score}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Question review list */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Award size={18} className="text-slate-400" /> Question-by-Question Appraisal
        </h3>

        <div className="space-y-3">
          {questions.map((q) => {
            const isExpanded = expandedQuestionId === q.id;
            return (
              <div 
                key={q.id}
                className={`rounded-xl border transition-all ${isExpanded ? 'bg-[#0A0C10]/90 border-white/10' : 'bg-[#07090D]/50 border-white/5 hover:border-white/10'}`}
              >
                {/* Header Row */}
                <div 
                  onClick={() => toggleQuestionExpand(q.id)}
                  className="p-4 flex items-center justify-between cursor-pointer select-none"
                >
                  <div className="flex items-center gap-3.5 flex-1 min-w-0">
                    <span className="rounded bg-white/5 px-2 py-0.5 text-[9px] font-mono font-bold text-slate-400 border border-white/5">
                      Q {q.index + 1}
                    </span>
                    <h4 className="font-bold text-slate-200 text-xs md:text-sm leading-snug flex-1 truncate min-w-0">
                      {q.question}
                    </h4>
                  </div>

                  <div className="flex items-center gap-3 pl-4">
                    {q.isAnswered && q.feedback ? (
                      <div className="flex items-center gap-2 font-mono">
                        <span className="text-[10px] text-slate-500">SCORE:</span>
                        <span className={`text-xs font-bold ${q.feedback.score >= 80 ? 'text-emerald-400' : q.feedback.score >= 60 ? 'text-amber-400' : 'text-rose-400'}`}>
                          {q.feedback.score}%
                        </span>
                      </div>
                    ) : (
                      <span className="text-[9px] font-mono font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">Unanswered</span>
                    )}

                    {isExpanded ? <ChevronDown size={14} className="text-slate-500" /> : <ChevronRight size={14} className="text-slate-500" />}
                  </div>
                </div>

                {/* Collapsible Content */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-3 border-t border-white/5 grid gap-5 md:grid-cols-12 bg-black/15">
                    
                    {/* User's Answer Panel */}
                    <div className="md:col-span-6 space-y-4">
                      <div className="space-y-1.5">
                        <h5 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Your Submitted Response:</h5>
                        <p className="text-xs text-slate-300 leading-relaxed bg-black/40 p-4 rounded-xl border border-white/5 whitespace-pre-wrap font-light italic">
                          {q.userAnswer ? `"${q.userAnswer}"` : "[No response was submitted]"}
                        </p>
                      </div>

                      {q.feedback && (
                        <div className="p-3.5 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
                          <h5 className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-1 font-mono">
                            <MessageSquare size={11} /> Speech & Delivery Guidance
                          </h5>
                          <p className="text-xs text-slate-300 leading-relaxed font-light">
                            {q.feedback.communicationFeedback}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Gemini Evaluation & ideal answer Panel */}
                    <div className="md:col-span-6 space-y-4">
                      {q.feedback ? (
                        <>
                          <div className="grid gap-4 sm:grid-cols-2">
                            <div className="space-y-1.5">
                              <h5 className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-1 font-mono">
                                <CheckCircle2 size={11} /> Strengths
                              </h5>
                              <ul className="text-xs text-slate-300 space-y-1 list-disc pl-4 leading-relaxed font-light">
                                {q.feedback.pros.map((p, idx) => (
                                  <li key={idx}>{p}</li>
                                ))}
                              </ul>
                            </div>
                            <div className="space-y-1.5">
                              <h5 className="text-[10px] font-bold text-rose-450 uppercase tracking-widest flex items-center gap-1 font-mono">
                                <XCircle size={11} /> Gaps
                              </h5>
                              <ul className="text-xs text-slate-300 space-y-1 list-disc pl-4 leading-relaxed font-light">
                                {q.feedback.cons.map((c, idx) => (
                                  <li key={idx}>{c}</li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          <div className="p-3.5 rounded-xl bg-cyan-950/10 border border-cyan-500/10 space-y-1.5">
                            <h5 className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-1 font-mono">
                              <BookOpen size={11} /> Exemplary STAR Response
                            </h5>
                            <p className="text-xs text-slate-300 leading-relaxed italic font-light">
                              "{q.feedback.betterResponse}"
                            </p>
                          </div>
                        </>
                      ) : (
                        <p className="text-xs text-slate-500 italic font-light">Submit answer during simulation to retrieve analytical grading.</p>
                      )}
                    </div>

                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
