import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  app.use(express.json());
  const PORT = 3000;

  // Initialize Gemini AI Client
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // API Route: Generate Interview Questions
  app.post("/api/generate-questions", async (req, res) => {
    try {
      const { role, company, experienceLevel, numQuestions = 5 } = req.body;

      if (!role) {
        return res.status(400).json({ error: "Role is required" });
      }

      const prompt = `
        You are an elite corporate interviewer. Generate ${numQuestions} highly realistic interview questions tailored for the following profile:
        - Target Role: ${role}
        - Target Company: ${company || "General/Standard"}
        - Experience Level: ${experienceLevel || "Mid-Level"}

        Create a diverse mix of questions:
        - Technical questions testing hard domain knowledge.
        - Behavioral questions (STAR format) testing conflict, teamwork, and leadership.
        - Situational questions testing problem-solving under constraints.
        - Resume/General questions testing experience and core drive.

        Make sure the questions reflect current industry standards and the specified company's culture/vibe if available.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are an expert tech recruiter and hiring manager. Your questions must be clear, relevant, and challenging but appropriate for the specified experience level.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING, description: "The actual question text for the candidate." },
                category: { type: Type.STRING, description: "Must be 'Behavioral', 'Technical', 'Situational', 'Resume', or 'General'." }
              },
              required: ["question", "category"]
            }
          }
        }
      });

      const questionsText = response.text || "[]";
      res.json(JSON.parse(questionsText));
    } catch (error: any) {
      console.error("Error in generate-questions:", error);
      res.status(500).json({ error: error.message || "Failed to generate questions" });
    }
  });

  // API Route: Analyze Answer
  app.post("/api/analyze-answer", async (req, res) => {
    try {
      const { question, userAnswer, category, role } = req.body;

      if (!question || !userAnswer) {
        return res.status(400).json({ error: "Question and userAnswer are required." });
      }

      const prompt = `
        Analyze the candidate's response to the interview question below for the role of ${role || "Candidate"}.
        
        Question: "${question}"
        Category: "${category || "General"}"
        Candidate's Answer: "${userAnswer}"

        Perform a professional evaluation:
        1. Score the answer from 0 to 100 based on completeness, accuracy, structure (e.g., STAR method for behavioral), and technical precision.
        2. Identify exact 'pros' (strengths, good phrasing, strong examples).
        3. Identify constructive 'cons' (gaps, areas of improvement, lack of detail).
        4. Provide a 'betterResponse' that represents a top-tier, polished model answer using elite industry keywords and standard frameworks (STAR, etc.).
        5. Provide helpful 'communicationFeedback' detailing the tone, delivery, structural flow, and impact of their answer.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are a senior hiring coach. Be encouraging yet rigorous and constructive in your critique. Provide clear feedback and a brilliant model answer.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.INTEGER, description: "A score from 0 to 100 assessing the completeness and quality of the answer." },
              pros: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of positive points about the user's answer." },
              cons: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of constructive critiques or missed opportunities." },
              betterResponse: { type: Type.STRING, description: "A detailed, professionally polished ideal model response that the user could have given." },
              communicationFeedback: { type: Type.STRING, description: "Specific comments on delivery, structure, clarity, or tone." }
            },
            required: ["score", "pros", "cons", "betterResponse", "communicationFeedback"]
          }
        }
      });

      const feedbackText = response.text || "{}";
      res.json(JSON.parse(feedbackText));
    } catch (error: any) {
      console.error("Error in analyze-answer:", error);
      res.status(500).json({ error: error.message || "Failed to analyze answer" });
    }
  });

  // API Route: Generate Overall Feedback for Completed Session
  app.post("/api/generate-overall-feedback", async (req, res) => {
    try {
      const { role, company, experienceLevel, responses } = req.body;

      if (!responses || !Array.isArray(responses) || responses.length === 0) {
        return res.status(400).json({ error: "Responses are required to compile overall feedback." });
      }

      const prompt = `
        Summarize the interview session for a candidate seeking a ${role} position at ${company || "General/Standard"} as a ${experienceLevel || "Mid-Level"} professional.
        
        The candidate has answered several questions and received individual scores. Here is the transcript and evaluation for each question:
        
        ${responses.map((r, index) => `
          Question ${index + 1}: "${r.question}"
          Category: "${r.category}"
          Candidate's Answer: "${r.userAnswer || "No answer provided"}"
          Question Score: ${r.feedback?.score || 0}
          Pros: ${r.feedback?.pros?.join(", ") || "None"}
          Cons: ${r.feedback?.cons?.join(", ") || "None"}
        `).join("\n---\n")}

        Synthesize this into a cohesive performance report:
        1. Calculate a fair overall score (0-100) taking into account the depth and development across all answers.
        2. Provide custom, highly action-oriented 'feedback' coaching notes (general strengths, overall developmental suggestions, key gaps in STAR structure or depth, and structural suggestions).
        3. Break down performance into four categories (technical, communication, problemSolving, situational), scoring each from 0 to 100.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are an elite interview coach compiling a comprehensive progress report. Your tone must be highly constructive, structured, and filled with highly practical, actionable coaching strategies.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.INTEGER, description: "Overall average interview score from 0 to 100." },
              feedback: { type: Type.STRING, description: "Comprehensive personalized coaching summary with actionable improvement advice." },
              categoryScores: {
                type: Type.OBJECT,
                properties: {
                  technical: { type: Type.INTEGER, description: "Score from 0 to 100 assessing technical/domain correctness." },
                  communication: { type: Type.INTEGER, description: "Score from 0 to 100 assessing delivery and clarity." },
                  problemSolving: { type: Type.INTEGER, description: "Score from 0 to 100 assessing structure and logic." },
                  situational: { type: Type.INTEGER, description: "Score from 0 to 100 assessing adaptability and situational logic." }
                },
                required: ["technical", "communication", "problemSolving", "situational"]
              }
            },
            required: ["score", "feedback", "categoryScores"]
          }
        }
      });

      const overallFeedbackText = response.text || "{}";
      res.json(JSON.parse(overallFeedbackText));
    } catch (error: any) {
      console.error("Error in generate-overall-feedback:", error);
      res.status(500).json({ error: error.message || "Failed to generate overall feedback" });
    }
  });

  // Serve Vite application or static assets
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AI Interview Coach server running on port ${PORT}`);
  });
}

startServer();
